# app/controllers/relationships_controller.rb

class RelationshipsController < ApplicationController
  before_action :authenticate_user!

  def create
    user = User.find(params[:followed_id])
    current_user.follow(user)
    redirect_back(fallback_location: root_path, notice: "You are now following #{user.username}.")
  end

  def destroy
    user = Relationship.find(params[:id]).followed
    current_user.unfollow(user)
    redirect_back(fallback_location: root_path, notice: "You are now following #{user.username}.")
  end
end
